/**
 * YOUTUBE AUTOMATION - SCRIPT GENERATOR
 * ======================================
 * This runs inside a Google Sheet (Extensions > Apps Script).
 * It reads topics from column A, calls Gemini API to generate
 * a video script + title + description + stock-video search keywords,
 * and writes everything back to the sheet + a JSON file in Drive
 * that the GitHub Actions video-assembly step will read.
 *
 * SETUP STEPS:
 * 1. Create a new Google Sheet.
 * 2. Extensions > Apps Script. Paste this file's contents in.
 * 3. Run setApiKey() once (edit YOUR_GEMINI_KEY first) to store your key safely.
 * 4. In the Sheet, put topics in column A starting row 2 (row 1 = headers).
 *    Example headers: Topic | Status | Title | Script | Keywords | DriveFileLink
 * 5. Run setup() once to create headers + the output folder in Drive.
 * 6. Run createDailyTrigger() once to schedule generateScripts() daily.
 * 7. Each day it will: find rows where Status is empty, generate content,
 *    mark Status = "READY", and save a JSON file per row to a Drive folder
 *    named "yt-automation-output".
 * 8. That Drive folder needs to be synced/downloaded to the GitHub repo's
 *    /input folder (manually, or via a Drive-to-GitHub sync tool — see notes
 *    at the bottom of this file for the simplest free approach).
 */

const GEMINI_MODEL = "gemini-1.5-flash"; // free-tier friendly model
const DRIVE_FOLDER_NAME = "yt-automation-output";

// ---- ONE-TIME SETUP ----

function setApiKey() {
  // Replace with your real Gemini API key from https://aistudio.google.com/app/apikey
  const YOUR_GEMINI_KEY = "PASTE_YOUR_GEMINI_API_KEY_HERE";
  PropertiesService.getScriptProperties().setProperty("GEMINI_API_KEY", YOUR_GEMINI_KEY);
  Logger.log("API key saved.");
}

function setup() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  const headers = ["Topic", "Status", "Title", "Script", "Description", "Keywords", "DriveFileName"];
  sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  sheet.setFrozenRows(1);

  // Create output folder in Drive if it doesn't exist
  const folders = DriveApp.getFoldersByName(DRIVE_FOLDER_NAME);
  if (!folders.hasNext()) {
    DriveApp.createFolder(DRIVE_FOLDER_NAME);
    Logger.log("Created Drive folder: " + DRIVE_FOLDER_NAME);
  } else {
    Logger.log("Drive folder already exists.");
  }
  Logger.log("Setup complete. Add topics in column A, then run createDailyTrigger().");
}

function createDailyTrigger() {
  // Remove existing triggers for this function first to avoid duplicates
  const triggers = ScriptApp.getProjectTriggers();
  triggers.forEach(t => {
    if (t.getHandlerFunction() === "generateScripts") {
      ScriptApp.deleteTrigger(t);
    }
  });

  ScriptApp.newTrigger("generateScripts")
    .timeBased()
    .everyDays(1)
    .atHour(6) // runs ~6AM in your script's timezone
    .create();

  Logger.log("Daily trigger created for generateScripts().");
}

// ---- MAIN AUTOMATION ----

function generateScripts() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  const data = sheet.getDataRange().getValues();
  const apiKey = PropertiesService.getScriptProperties().getProperty("GEMINI_API_KEY");

  if (!apiKey || apiKey === "PASTE_YOUR_GEMINI_API_KEY_HERE") {
    Logger.log("ERROR: Gemini API key not set. Run setApiKey() with your real key first.");
    return;
  }

  const folder = DriveApp.getFoldersByName(DRIVE_FOLDER_NAME).next();

  for (let row = 1; row < data.length; row++) {
    const topic = data[row][0];
    const status = data[row][1];

    if (!topic || status === "READY" || status === "PROCESSING") continue;

    sheet.getRange(row + 1, 2).setValue("PROCESSING");

    try {
      const result = callGemini(apiKey, topic);

      // Write results back to sheet
      sheet.getRange(row + 1, 3).setValue(result.title);
      sheet.getRange(row + 1, 4).setValue(result.script);
      sheet.getRange(row + 1, 5).setValue(result.description);
      sheet.getRange(row + 1, 6).setValue(result.keywords.join(", "));

      // Save JSON file to Drive for the video-assembly pipeline
      const fileName = "video_" + new Date().getTime() + "_row" + (row + 1) + ".json";
      const payload = {
        topic: topic,
        title: result.title,
        script: result.script,
        description: result.description,
        keywords: result.keywords,
        scenes: result.scenes
      };
      folder.createFile(fileName, JSON.stringify(payload, null, 2), MimeType.PLAIN_TEXT);

      sheet.getRange(row + 1, 7).setValue(fileName);
      sheet.getRange(row + 1, 2).setValue("READY");

    } catch (e) {
      sheet.getRange(row + 1, 2).setValue("ERROR: " + e.message);
      Logger.log("Error on row " + (row + 1) + ": " + e.message);
    }

    // Avoid hitting free-tier rate limits (15 requests/minute)
    Utilities.sleep(5000);
  }
}

// ---- GEMINI API CALL ----

function callGemini(apiKey, topic) {
  const url = "https://generativelanguage.googleapis.com/v1beta/models/" + GEMINI_MODEL + ":generateContent?key=" + apiKey;

  const prompt = `You are writing a YouTube Shorts script (vertical video, 30-50 seconds when spoken).
Topic: "${topic}"

Return ONLY valid JSON (no markdown, no code fences) with this exact structure:
{
  "title": "catchy YouTube title under 70 characters",
  "description": "2-3 sentence YouTube description with relevant hashtags",
  "script": "the full voiceover script as one block of text, written for natural spoken delivery, 30-50 seconds long",
  "scenes": [
    {"text": "first sentence or two of the script", "keyword": "2-3 word stock video search term that visually matches this part"},
    {"text": "next sentence or two", "keyword": "2-3 word stock video search term"}
  ],
  "keywords": ["overall video", "search terms", "list of 5 short phrases"]
}

Break the script into 4-6 scenes. Each scene's "keyword" must be a simple, literal, searchable term (e.g. "ocean waves", "city traffic night", "person typing laptop") that would return relevant results on a stock video site. Do not include any text outside the JSON object.`;

  const payload = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.8,
      maxOutputTokens: 1024
    }
  };

  const options = {
    method: "post",
    contentType: "application/json",
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  const response = UrlFetchApp.fetch(url, options);
  const responseCode = response.getResponseCode();
  const responseText = response.getContentText();

  if (responseCode !== 200) {
    throw new Error("Gemini API error " + responseCode + ": " + responseText);
  }

  const json = JSON.parse(responseText);
  let text = json.candidates[0].content.parts[0].text;

  // Strip markdown code fences if Gemini adds them despite instructions
  text = text.replace(/```json/g, "").replace(/```/g, "").trim();

  const parsed = JSON.parse(text);
  return parsed;
}

/*
 * NOTE ON GETTING FILES FROM DRIVE INTO GITHUB (the missing link):
 * ------------------------------------------------------------------
 * The GitHub Actions workflow in this project reads JSON files from
 * the repo's /input folder. To get files from your Drive folder
 * ("yt-automation-output") into that GitHub /input folder for FREE
 * with no daily manual work, the simplest reliable option is:
 *
 *   Add a second function (below) that, instead of saving to Drive,
 *   pushes the JSON directly to your GitHub repo via the GitHub API
 *   using a Personal Access Token. This removes the Drive middle-step
 *   entirely. See pushToGithub() — call this instead of/alongside
 *   folder.createFile() in generateScripts() if you want full automation
 *   with zero manual file transfers.
 */

function pushToGithub(fileName, jsonContent) {
  // Fill these in with your own values.
  const GITHUB_TOKEN = "PASTE_YOUR_GITHUB_PERSONAL_ACCESS_TOKEN"; // repo scope
  const GITHUB_USER = "your-github-username";
  const GITHUB_REPO = "your-repo-name";
  const BRANCH = "main";

  const path = "input/" + fileName;
  const url = `https://api.github.com/repos/${GITHUB_USER}/${GITHUB_REPO}/contents/${path}`;

  const payload = {
    message: "Add new video script: " + fileName,
    content: Utilities.base64Encode(jsonContent),
    branch: BRANCH
  };

  const options = {
    method: "put",
    contentType: "application/json",
    headers: {
      Authorization: "token " + GITHUB_TOKEN
    },
    payload: JSON.stringify(payload),
    muteHttpExceptions: true
  };

  const response = UrlFetchApp.fetch(url, options);
  Logger.log("GitHub push response: " + response.getResponseCode());
}
